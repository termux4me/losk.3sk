<?php
include('simple_html_dom.php');
include('.color.php');
$a=array("#ff6699", "#cc00ff", "red", "black", "green", "blue", "#c3008a", "#ff33fb", "#ff334a", "#ff0066");
$k1 = rand(1,10);
$col = "$a[$k1]";
echo '<html><meta name="viewport" content="width=device-width, initial-scale=2, maximum-scale=2"><body bgcolor="black">
<style>
h1 {
 font-size: 72px;
 color: white;
 text-shadow: -3px 0 #' . $color1 . ', 0 3px #' . $color2 . ', 3px 0 #' . $color3 . ', 0 -3px #' . $color4 . ';
 background-color: black;
}
h2, h3 {
  color: white;
  background-color: black;
}
img {
 border: 3px solid #' . $color1 . ';
}
table {
 padding: 5px;
 text-align:center;
 width:100%;
 margin-left:1%;
 margin-right:10%;
}
p {
 border: 5px solid ' . $col . ';
}
.btn {
  background-color: #f4511e;
  color: white;
  padding: 16px 32px;
  text-align: center;
  font-size: 44px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
  border: 3px solid #' . $color1 . ';
}
.btn:hover {opacity: 24}
</style>
<table><td bgcolor="white">
';

$s='
';
function gb($url) {
 $html = file_get_html($url);
  foreach($html->find('div[class=container-fluid]') as $hm) {
   foreach($hm->find('a') as $a) {
     $ba=$a->href;
     $ba=preg_split("/&/", $ba);
     $ba='https://3sk.co/vb/showthread.php?' . $ba[1];
     $ba=preg_replace("/amp;/",'',$ba);
     $bt=$a->plaintext;
     echo '<h3>' . $bt . '</h3><a href="/s/index.php?url=' . urlencode($ba) . '">     رابط الحلقة</a><p></p></br>';
     if (preg_match("/نهاية الموسم/", $bt)) :
       echo '<h1>نهاية الموسم</h1>';
       endif;
   }
  }
}
function li($li) {
  if (preg_match("/https:\/\/tune.pk\/js\/open\/load/", $li)) :
     $tunepk=preg_split("/=/", $li);
     $li='https://tune.pk/video/' . $tunepk[1] ;
    endif;
 echo '<h2>رابط المشاهدة</h2><a href="' . $li . '">' . $li . '</a><p></p>';
}

function yt($li) {
  if (preg_match("/youtube/", $li)) :
    li($li);
    endif;
}
function linked($html,$tg,$hrs,$li) {
  foreach($html->find('div[class=dimPlayerBlock]') as $hm) {
    foreach($hm->find($tg) as $fin) {
      $fli=$fin->$hrs;
      if ( $fli != '') {
       li($fli);
      }
    }
  }
}
function index() {
echo "<p><h1>أحدث الحلقات</h1></p>";
$s0='<div class="btn"></br><a href="/s/index.php?url=';
$s1='"><img src="https://3sk.co/';
$s2='"/></a></br><a href="/s/index.php?url=';
$s3='">';
$s4='</a></div></br><p></p>';
$url = "https://3sk.co/";
$html = file_get_html($url);
 foreach($html->find('div[class=article]') as $hm) {
  foreach($hm->find('img') as $b) {
   foreach($hm->find('h2') as $h) {
    foreach($h->find('a') as $c) {
     foreach($hm->find('p') as $a) {
     $yo=$c->href;
     echo $s0 . urlencode($yo) . $s1 . $b->src . $s2 . urlencode($yo) . $s3 . $a->plaintext . $s4;
     }
    }
   }
  }
 }
}

function ops($url) {
echo "<p><h1>الروابط</h1></p>";
$html = file_get_html($url);
$links = array();
foreach($html->find('div[class=postat-hyper]') as $hm) {
 foreach($hm->find('a') as $b) {
 $links[]=$b->href;
 }
}
foreach($links as $link) {
 $html = file_get_html($link);
 foreach($html->find('div[id=red_link]') as $hm) {
   foreach($hm->find('a') as $b) {
    $li=$b->href;
    $html = file_get_html($li);
    //echo $li , $s . '</br></br>';
    yt($li);
    linked($html,'a','href',$li);
    linked($html,'script','src',$li);
    linked($html,'iframe','src',$li);
   }
  }
 }
}
$url=$_GET["url"];
$url=urldecode($url);
if (preg_match('/showthread.php/',$url)) {
 ops($url);
} elseif (preg_match('/forumdisplay.php/',$url)) {
 gb($url);
} elseif ( $url == '') {
 index();
}

echo "
</td>
</table>
</body></html>";



?>
